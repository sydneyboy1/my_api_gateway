<?php
// Configuration file for API Gateway

// Valid API keys mapped to user names
$valid_api_keys = [
    'key123' => 'UserA',
    'key456' => 'UserB',
    'key789' => 'UserC'
];

// Rate limit settings
$rate_limit = [
    'requests' => 10,    // Number of requests allowed
    'window' => 60       // Time window in seconds (1 minute)
];
?>