<?php
// Load configuration
require_once __DIR__ . '/config.php';

// Create necessary directories if they don't exist
if (!is_dir(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}
if (!is_dir(__DIR__ . '/ratelimit_data')) {
    mkdir(__DIR__ . '/ratelimit_data', 0755, true);
}

// Get the requested path from the URL
$request_path = isset($_GET['request_path']) ? $_GET['request_path'] : '';

// Get all headers
$headers = getallheaders();

// Check for API key
$api_key = isset($headers['X-API-Key']) ? $headers['X-API-Key'] : '';

// Get client IP address
$client_ip = $_SERVER['REMOTE_ADDR'];

// Default HTTP status code (will be updated as needed)
$status_code = 200;

// Log function to centralize logging logic
function log_request($client_ip, $api_key, $request_path, $status_code) {
    $log_message = sprintf(
        "[%s] - IP: [%s] - API Key: [%s] - Path: [%s] - Status: [%d]\n",
        date('Y-m-d H:i:s'),
        $client_ip,
        $api_key ?: 'None',
        $request_path,
        $status_code
    );
    file_put_contents(__DIR__ . '/logs/gateway.log', $log_message, FILE_APPEND);
}

// Validate API key
if (empty($api_key) || !isset($valid_api_keys[$api_key])) {
    // Invalid or missing API key
    header('Content-Type: application/json');
    $status_code = 401;
    http_response_code($status_code);
    echo json_encode(['error' => 'Invalid or missing API Key']);
    
    // Log the failed attempt
    log_request($client_ip, $api_key, $request_path, $status_code);
    exit;
}

// User is authenticated, now check rate limit
$rate_limit_file = __DIR__ . '/ratelimit_data/' . md5($api_key) . '.json';
$current_time = time();
$rate_limited = false;

// Check if rate limit file exists
if (file_exists($rate_limit_file)) {
    $rate_data = json_decode(file_get_contents($rate_limit_file), true);
    
    // Check if we're still within the time window
    if ($current_time - $rate_data['timestamp'] <= $rate_limit['window']) {
        // Still within time window, check count
        if ($rate_data['count'] >= $rate_limit['requests']) {
            // Rate limit exceeded
            header('Content-Type: application/json');
            $status_code = 429;
            http_response_code($status_code);
            echo json_encode(['error' => 'Rate limit exceeded']);
            $rate_limited = true;
            
            // Log the rate limit
            log_request($client_ip, $api_key, $request_path, $status_code);
            exit;
        } else {
            // Increment the counter
            $rate_data['count']++;
        }
    } else {
        // Outside time window, reset counter
        $rate_data = [
            'timestamp' => $current_time,
            'count' => 1
        ];
    }
} else {
    // First request, initialize counter
    $rate_data = [
        'timestamp' => $current_time,
        'count' => 1
    ];
}

// Save updated rate limit data
file_put_contents($rate_limit_file, json_encode($rate_data));

// If not rate limited, process the request
if (!$rate_limited) {
    // Start output buffering
    ob_start();

    // Route based on the requested path
    if ($request_path === 'users') {
        require_once __DIR__ . '/services/service_users.php';
    } elseif ($request_path === 'products') {
        require_once __DIR__ . '/services/service_products.php';
    } else {
        // If path doesn't match any service
        header('Content-Type: application/json');
        $status_code = 404;
        http_response_code($status_code);
        echo json_encode(['error' => 'Service not found']);
    }

    // Get the output content
    $output = ob_get_clean();
    
    // Send the output to the client
    echo $output;
    
    // Log successful request
    log_request($client_ip, $api_key, $request_path, $status_code);
}
?>