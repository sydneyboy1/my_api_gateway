<?php
// Set content type header
header('Content-Type: application/json');

// Simple array of dummy product data
$products = [
    ["sku" => "A123", "productName" => "Widget", "price" => 19.99],
    ["sku" => "B456", "productName" => "Gadget", "price" => 24.99],
    ["sku" => "C789", "productName" => "Doohickey", "price" => 14.99],
    ["sku" => "D012", "productName" => "Thingamajig", "price" => 29.99]
];

// Output the data as JSON
echo json_encode($products);
?>