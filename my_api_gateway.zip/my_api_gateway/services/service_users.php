<?php
// Set content type header
header('Content-Type: application/json');

// Simple array of dummy user data
$users = [
    ["id" => 1, "name" => "Alice"],
    ["id" => 2, "name" => "Bob"],
    ["id" => 3, "name" => "Charlie"],
    ["id" => 4, "name" => "Diana"]
];

// Output the data as JSON
echo json_encode($users);
?>